package terraform.security.iam

deny[msg] {
  resource := input.resource_changes[_]
  contains(resource.type, "iam")
  permissions := resource.change.after.policy.Statement[_].Action
  permissions == "*"
  msg := sprintf("Wildcard IAM action is not allowed in %s", [resource.address])
}

deny[msg] {
  resource := input.resource_changes[_]
  contains(resource.type, "iam")
  statement := resource.change.after.policy.Statement[_]
  statement.Resource == "*"
  statement.Effect == "Allow"
  msg := sprintf("Wildcard IAM resource is not allowed in %s", [resource.address])
}
