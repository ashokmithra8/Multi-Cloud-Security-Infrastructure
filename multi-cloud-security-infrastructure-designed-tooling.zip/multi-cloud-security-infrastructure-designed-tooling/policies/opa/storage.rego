package terraform.security.storage

deny[msg] {
  resource := input.resource_changes[_]
  resource.type == "aws_s3_bucket_public_access_block"
  after := resource.change.after
  not after.block_public_acls
  msg := sprintf("S3 public ACLs must be blocked for %s", [resource.address])
}

deny[msg] {
  resource := input.resource_changes[_]
  resource.type == "google_storage_bucket"
  after := resource.change.after
  not after.uniform_bucket_level_access
  msg := sprintf("GCP buckets must use uniform bucket-level access for %s", [resource.address])
}

deny[msg] {
  resource := input.resource_changes[_]
  resource.type == "azurerm_storage_account"
  after := resource.change.after
  after.allow_nested_items_to_be_public
  msg := sprintf("Azure storage accounts must not allow public nested items for %s", [resource.address])
}
