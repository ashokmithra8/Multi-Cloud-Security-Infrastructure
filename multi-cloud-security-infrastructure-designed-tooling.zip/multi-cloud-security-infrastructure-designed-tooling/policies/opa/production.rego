package terraform.security.production

deny[msg] {
  input.variables.environment.value == "prod"
  resource := input.resource_changes[_]
  resource.type == "aws_s3_bucket"
  not resource.change.after.versioning[0].enabled
  msg := sprintf("Production S3 buckets must enable versioning for %s", [resource.address])
}

deny[msg] {
  input.variables.environment.value == "prod"
  resource := input.resource_changes[_]
  resource.type == "google_storage_bucket"
  not resource.change.after.versioning[0].enabled
  msg := sprintf("Production GCP buckets must enable versioning for %s", [resource.address])
}
