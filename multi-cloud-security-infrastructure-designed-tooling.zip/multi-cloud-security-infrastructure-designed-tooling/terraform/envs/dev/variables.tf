variable "environment" {
  description = "Deployment environment name."
  type        = string
  default     = "dev"
}

variable "project_name" {
  description = "Short name used in cloud resource names."
  type        = string
  default     = "multi-cloud-security"
}

variable "model_artifact_owner" {
  description = "Team responsible for model assets."
  type        = string
  default     = "ml-platform"
}

variable "aws_region" {
  description = "AWS region for the baseline."
  type        = string
  default     = "us-east-1"
}

variable "azure_location" {
  description = "Azure location for the baseline."
  type        = string
  default     = "eastus"
}

variable "gcp_project_id" {
  description = "GCP project ID."
  type        = string
}

variable "gcp_region" {
  description = "GCP region for the baseline."
  type        = string
  default     = "us-central1"
}
