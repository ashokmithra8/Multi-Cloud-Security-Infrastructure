output "aws_model_artifact_bucket" {
  description = "Private AWS S3 bucket for model artifacts."
  value       = module.aws_secure_baseline.model_artifact_bucket
}

output "azure_model_artifact_storage_account" {
  description = "Private Azure Storage account for model artifacts."
  value       = module.azure_secure_baseline.model_artifact_storage_account
}

output "gcp_model_artifact_bucket" {
  description = "Private GCP Cloud Storage bucket for model artifacts."
  value       = module.gcp_secure_baseline.model_artifact_bucket
}
