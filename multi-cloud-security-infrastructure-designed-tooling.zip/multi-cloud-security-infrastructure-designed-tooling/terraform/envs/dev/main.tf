terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

provider "azurerm" {
  features {}
}

provider "google" {
  project = var.gcp_project_id
  region  = var.gcp_region
}

module "aws_secure_baseline" {
  source = "../../modules/aws-secure-baseline"

  environment          = var.environment
  project_name         = var.project_name
  model_artifact_owner = var.model_artifact_owner
}

module "azure_secure_baseline" {
  source = "../../modules/azure-secure-baseline"

  environment          = var.environment
  project_name         = var.project_name
  location             = var.azure_location
  model_artifact_owner = var.model_artifact_owner
}

module "gcp_secure_baseline" {
  source = "../../modules/gcp-secure-baseline"

  environment          = var.environment
  project_name         = var.project_name
  location             = var.gcp_region
  model_artifact_owner = var.model_artifact_owner
}
