resource "google_kms_key_ring" "model_assets" {
  name     = "${var.project_name}-${var.environment}-models"
  location = var.location
}

resource "google_kms_crypto_key" "model_assets" {
  name            = "model-assets"
  key_ring        = google_kms_key_ring.model_assets.id
  rotation_period = "7776000s"
}

resource "google_storage_bucket" "model_assets" {
  name                        = "${var.project_name}-${var.environment}-models"
  location                    = var.location
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"

  encryption {
    default_kms_key_name = google_kms_crypto_key.model_assets.id
  }

  versioning {
    enabled = true
  }

  labels = local.labels
}
