output "model_artifact_bucket" {
  description = "Name of the private model artifact bucket."
  value       = google_storage_bucket.model_assets.name
}
