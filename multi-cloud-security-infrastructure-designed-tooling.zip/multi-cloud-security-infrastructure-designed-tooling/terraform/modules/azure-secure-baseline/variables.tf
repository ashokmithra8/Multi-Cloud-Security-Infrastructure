variable "environment" {
  description = "Deployment environment name."
  type        = string
}

variable "project_name" {
  description = "Short name used in cloud resource names."
  type        = string
}

variable "location" {
  description = "Azure location for resources."
  type        = string
}

variable "model_artifact_owner" {
  description = "Team responsible for model assets."
  type        = string
}

locals {
  tags = {
    project     = var.project_name
    environment = var.environment
    owner       = var.model_artifact_owner
    managed_by  = "terraform"
  }
}
