output "model_artifact_storage_account" {
  description = "Name of the private model artifact storage account."
  value       = azurerm_storage_account.model_assets.name
}
