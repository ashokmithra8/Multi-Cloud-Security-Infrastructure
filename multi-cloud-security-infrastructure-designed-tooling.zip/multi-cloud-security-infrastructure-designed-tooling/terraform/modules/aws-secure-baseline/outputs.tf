output "model_artifact_bucket" {
  description = "Name of the private model artifact bucket."
  value       = aws_s3_bucket.model_assets.id
}
