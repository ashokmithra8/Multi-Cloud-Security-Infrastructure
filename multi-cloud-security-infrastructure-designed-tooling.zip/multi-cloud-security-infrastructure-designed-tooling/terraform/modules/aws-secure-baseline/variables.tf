variable "environment" {
  description = "Deployment environment name."
  type        = string
}

variable "project_name" {
  description = "Short name used in cloud resource names."
  type        = string
}

variable "model_artifact_owner" {
  description = "Team responsible for model assets."
  type        = string
}

locals {
  tags = {
    Project     = var.project_name
    Environment = var.environment
    Owner       = var.model_artifact_owner
    ManagedBy   = "terraform"
  }
}
