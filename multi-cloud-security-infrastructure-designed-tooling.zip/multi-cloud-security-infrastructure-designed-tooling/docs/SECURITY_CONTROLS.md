# Security Controls

## Data Protection

- Encrypt all object storage with customer-managed keys where practical.
- Block public access to model artifact buckets and sensitive datasets.
- Require object versioning for production model artifacts.
- Maintain hashes for model files so tampering can be detected.

## Identity and Access Management

- Avoid wildcard administrator permissions.
- Scope identities to the environment they deploy.
- Use short-lived credentials through OIDC or workload identity federation.
- Separate human access from automation access.

## Network Security

- Keep production services on private networks.
- Prefer private endpoints for storage, key management, and databases.
- Restrict ingress to approved load balancers, service meshes, or API gateways.
- Log network flow data in production.

## Logging and Monitoring

- Enable cloud control plane audit logs.
- Send security logs to a central monitoring account or workspace.
- Protect logs from deletion with retention and immutability controls.
- Alert on public storage, disabled encryption, and privileged IAM changes.

## CI/CD Guardrails

- Run secret scanning on every pull request.
- Validate Terraform formatting and syntax.
- Run IaC scanners before deployment.
- Enforce custom policy-as-code checks for organization-specific risks.

## Model Asset Governance

- Track every model artifact in a manifest.
- Require ownership and classification metadata.
- Store approved deployment stage.
- Verify artifact hashes before promotion.
- Separate experimental assets from production-approved assets.
