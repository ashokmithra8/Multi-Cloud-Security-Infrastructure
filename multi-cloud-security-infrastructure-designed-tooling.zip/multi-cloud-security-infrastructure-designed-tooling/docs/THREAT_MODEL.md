# Threat Model

## Assets

- Sensitive datasets
- Trained model artifacts
- Cloud credentials
- Production infrastructure
- Audit logs
- CI/CD deployment workflows

## Primary Threats

| Threat | Impact | Mitigation |
| --- | --- | --- |
| Public storage exposure | Data or model theft | Public access blocks, policy checks, private endpoints |
| Leaked cloud credentials | Unauthorized cloud access | Secret scanning, OIDC federation, short-lived tokens |
| Overly broad IAM | Privilege escalation | Least privilege policies, review gates |
| Disabled logging | Loss of investigation evidence | Mandatory audit logging and retention |
| Model tampering | Unsafe production behavior | Hash validation and versioned storage |
| Unreviewed production change | Outage or security regression | CI checks and deployment approvals |

## Trust Boundaries

- Developer workstation to GitHub
- GitHub Actions to cloud provider APIs
- Cloud control plane to production network
- Model artifact storage to inference runtime
- Security logs to monitoring platform

## Assumptions

- Cloud accounts and subscriptions are already created.
- Production deployments use dedicated environments.
- Teams configure provider credentials securely outside this repository.
- This repository provides guardrails and examples, not a complete enterprise landing zone.
