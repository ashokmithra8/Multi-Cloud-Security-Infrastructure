# Architecture

This project is structured as a reusable security baseline for AWS, Azure, and GCP. Each cloud module applies the same security intent with provider-specific services.

## Design Goals

- Use infrastructure as code for repeatable deployments.
- Keep cloud identities least-privileged and environment-scoped.
- Encrypt sensitive data and model assets by default.
- Prevent public exposure of storage and production systems.
- Preserve audit evidence through cloud-native logging.
- Shift security checks left through CI and policy-as-code.

## High-Level Flow

1. A developer changes Terraform or policy code.
2. GitHub Actions validates formatting and Terraform syntax.
3. Secret scanning checks the repository for leaked credentials.
4. IaC scanning detects cloud misconfigurations.
5. OPA policies enforce organization-specific rules.
6. Approved changes can be planned and applied through the team's deployment workflow.

## Multi-Cloud Baseline

| Security Layer | AWS | Azure | GCP |
| --- | --- | --- | --- |
| Identity | IAM roles and policies | Azure RBAC | IAM roles |
| Key management | AWS KMS | Azure Key Vault | Cloud KMS |
| Artifact storage | S3 | Azure Storage | Cloud Storage |
| Network boundary | VPC | VNet | VPC |
| Audit logging | CloudTrail | Azure Monitor | Cloud Audit Logs |
| Policy guardrails | OPA, AWS Config | OPA, Azure Policy | OPA, Organization Policy |

## Model Asset Protection

Model assets should be treated like production software and sensitive data. The example manifest in `model-assets/manifest.example.json` tracks:

- Model name and version
- SHA-256 artifact hash
- Data classification
- Owning team
- Approved deployment stage
- Storage location

CI validates that required fields are present before assets can move forward.

## Production Deployment Boundary

Production environments should add:

- Mandatory private endpoints
- Separate KMS keys per environment
- Break-glass access with approval
- Immutable logging storage
- Continuous cloud posture monitoring
- Deployment approvals for high-risk infrastructure changes
