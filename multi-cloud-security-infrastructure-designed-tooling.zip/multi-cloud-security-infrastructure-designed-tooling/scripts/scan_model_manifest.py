#!/usr/bin/env python3
import hashlib
import json
import re
import sys
from pathlib import Path

REQUIRED_FIELDS = {
    "name",
    "version",
    "owner",
    "classification",
    "approved_stage",
    "artifact_uri",
    "sha256",
}

ALLOWED_CLASSIFICATIONS = {"internal", "confidential", "restricted"}
ALLOWED_STAGES = {"dev", "stage", "prod"}
SHA256_PATTERN = re.compile(r"^[a-fA-F0-9]{64}$")


def fail(message: str) -> None:
    print(f"manifest validation failed: {message}", file=sys.stderr)
    sys.exit(1)


def validate_model(model: dict, index: int) -> None:
    missing = REQUIRED_FIELDS - model.keys()
    if missing:
        fail(f"model #{index} is missing required fields: {', '.join(sorted(missing))}")

    if model["classification"] not in ALLOWED_CLASSIFICATIONS:
        fail(f"model #{index} has invalid classification: {model['classification']}")

    if model["approved_stage"] not in ALLOWED_STAGES:
        fail(f"model #{index} has invalid approved_stage: {model['approved_stage']}")

    if not SHA256_PATTERN.match(model["sha256"]):
        fail(f"model #{index} has invalid sha256 value")

    if model["approved_stage"] == "prod" and model["classification"] == "internal":
        fail(f"model #{index} cannot be production-approved with internal-only classification")


def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: scan_model_manifest.py <manifest.json>")

    manifest_path = Path(sys.argv[1])
    if not manifest_path.exists():
        fail(f"manifest not found: {manifest_path}")

    data = json.loads(manifest_path.read_text())
    models = data.get("models")
    if not isinstance(models, list) or not models:
        fail("manifest must contain a non-empty models list")

    seen = set()
    for index, model in enumerate(models, start=1):
        validate_model(model, index)
        identity = (model["name"], model["version"])
        if identity in seen:
            fail(f"duplicate model entry: {model['name']} {model['version']}")
        seen.add(identity)

    digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    print(f"manifest ok: {len(models)} model(s), manifest_sha256={digest}")


if __name__ == "__main__":
    main()
