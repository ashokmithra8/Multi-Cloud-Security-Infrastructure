#!/usr/bin/env bash
set -euo pipefail

if command -v terraform >/dev/null 2>&1; then
  terraform -chdir=terraform/envs/dev init -backend=false
  terraform -chdir=terraform/envs/dev validate
else
  echo "terraform not installed; skipping Terraform validation"
fi

if command -v conftest >/dev/null 2>&1; then
  conftest test terraform/envs/dev --policy policies/opa
else
  echo "conftest not installed; skipping OPA policy validation"
fi

if command -v checkov >/dev/null 2>&1; then
  checkov -d terraform --quiet
else
  echo "checkov not installed; skipping IaC misconfiguration scan"
fi

if command -v gitleaks >/dev/null 2>&1; then
  gitleaks detect --source .
else
  echo "gitleaks not installed; skipping secret scan"
fi

python3 scripts/scan_model_manifest.py model-assets/manifest.example.json
